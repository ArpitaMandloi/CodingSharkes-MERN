//=======================Call Stack==========================
// Call Stack ek stack hota hai jahan JavaScript ke currently executing functions rakhe jaate hain.
// function one() {
//     console.log("One");
// }
// function two() {
//     one();
// }
// two();
// Flow:
// two() → one() → console.log()

//=======================Web APIs==========================
// Browser JavaScript ko kuch extra capabilities provide karta hai, jaise setTimeout, setInterval, fetch, DOM events, etc.
// setTimeout(() => {
//     console.log("Hello");
// }, 2000);
// Timer ka waiting work browser ke timer mechanism ko diya ja sakta hai.

//=======================Event Loop========================
// Event Loop continuously check karta hai ki Call Stack empty hai ya nahi. Agar Call Stack empty ho aur queue mein callback ho, to callback ko Call Stack mein bheja ja sakta hai.
//     Flow:
// Web API / Timer → Task Queue → Event Loop → Call Stack → Execute
// Simple analogy: Event Loop ek receptionist ki tarah kaam karta hai jo waiting queue se next task ko tab bhejta hai jab Call Stack available ho.

//=======================Promise========================
// Promise asynchronous operation ke future result ko represent karta hai.
//     Example:
// const promise1 = new Promise((resolve, reject) => {
//     resolve("Success");
// });
// console.log(promise1);
// Promise ka basic idea: "Result abhi nahi mila hai, lekin future mein milega." 

// console.log("first");

// const promise2 = new Promise((resolve) => {
//     setTimeout(() => {
//         console.log("Hello");
//         resolve();
//     }, 2000);
// });

// promise2.then(() => {
//     console.log("Done");
// });

//=======================Promise States========================
// Promise ki 3 states hoti hain:
// 1. Pending — operation abhi complete nahi hua.
// 2. Resolve — operation successfully complete hua.
// 3. Rejected — operation fail hua.
//     Flow:
// Pending → Resolve
// OR
// Pending → Rejected

//=======================Async and Await========================
// function delay() {
//     return new Promise((resolve) => {
//         setTimeout(() => {
//             console.log("Arpita");
//             resolve();
//         }, 2000);
//     });
// }

// async function test() {
//     console.log("first");
//     await delay();
//     console.log("Hello");
// }
// test();

//=======================Fetch API=============================
// JavaScript mein fetch() ka use kisi server / API se data lene ya server ko data bhejne ke liye hota hai.
// Fetch = Server se baat karne ka JavaScript method
//                                 JavaScript
//                                      ↓
//                                  fetch()
//                                      ↓
//                                  Server / API
//                                      ↓
//                                  Users ka data
//                                      ↓
//                                  JavaScript
// async function getUsers() {
//     const response = await fetch(
//         "https://jsonplaceholder.typicode.com/users"
//     );
//     const data = await response.json();
//     console.log(data);
// }
// getUsers();

//=======================Async/Await with Error Handling========================
// async function getUsers() {
//     try {
//         const response = await fetch(
//             "https://jsonplaceholder.typicode.com/users"
//         );
//         const data = await response.json();
//         console.log(data);
//     } catch (error) {
//         console.log("Error:", error);
//     }
// }
// getUsers();
